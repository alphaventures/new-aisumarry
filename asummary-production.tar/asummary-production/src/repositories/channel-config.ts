import { BaseRepository } from './base';
import { Prisma } from '@prisma/client';

export class ChannelConfigRepository extends BaseRepository {
  async findById(id: bigint) {
    return this.withRetry(() =>
      this.db.channelconfig.findUnique({
        where: { id },
      })
    );
  }

  async findByIdOrThrow(id: bigint) {
    return this.withRetry(() =>
      this.db.channelconfig.findUniqueOrThrow({
        where: { id },
      })
    );
  }

  async findMany(ids: bigint[]) {
    return this.withRetry(() =>
      this.db.channelconfig.findMany({
        where: {
          id: { in: ids },
        },
      })
    );
  }

  async create(data: Prisma.channelconfigCreateInput) {
    return this.withRetry(() =>
      this.db.channelconfig.create({ data })
    );
  }

  async update(id: bigint, data: Prisma.channelconfigUpdateInput) {
    return this.withRetry(() =>
      this.db.channelconfig.update({
        where: { id },
        data,
      })
    );
  }

  async delete(id: bigint) {
    return this.withRetry(() =>
      this.db.channelconfig.delete({
        where: { id },
      })
    );
  }

  async deleteMany(ids: bigint[]) {
    return this.withRetry(() =>
      this.db.channelconfig.deleteMany({
        where: {
          id: { in: ids },
        },
      })
    );
  }

  async updateLanguage(id: bigint, lang: string) {
    return this.withRetry(() =>
      this.db.channelconfig.update({
        where: { id },
        data: { lang },
      })
    );
  }

  async updateAIPrompt(id: bigint, aiprompt: string) {
    return this.withRetry(() =>
      this.db.channelconfig.update({
        where: { id },
        data: { aiprompt },
      })
    );
  }

  async toggleAI(id: bigint, enabled: boolean) {
    return this.withRetry(() =>
      this.db.channelconfig.update({
        where: { id },
        data: { ai: enabled },
      })
    );
  }

  async toggleTranslate(id: bigint, enabled: boolean) {
    return this.withRetry(() =>
      this.db.channelconfig.update({
        where: { id },
        data: { translate: enabled },
      })
    );
  }

  async updateFooter(id: bigint, footer: string | null, footerKeyboard: string | null) {
    return this.withRetry(() =>
      this.db.channelconfig.update({
        where: { id },
        data: { 
          footer,
          footer_keyboard: footerKeyboard,
        },
      })
    );
  }

  async updateTextFormat(id: bigint, textformat: string | null) {
    return this.withRetry(() =>
      this.db.channelconfig.update({
        where: { id },
        data: { textformat },
      })
    );
  }
}
