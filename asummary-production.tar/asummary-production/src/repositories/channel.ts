import { BaseRepository } from './base';
import { Prisma } from '@prisma/client';

export class ChannelRepository extends BaseRepository {
  async findByOwnerId(ownerId: bigint) {
    return this.withRetry(() =>
      this.db.channels.findMany({
        where: { owned_by: ownerId },
        select: { channelid: true },
      })
    );
  }

  async findById(channelId: bigint) {
    return this.withRetry(() =>
      this.db.channels.findUnique({
        where: { channelid: channelId },
      })
    );
  }

  async findByIdOrThrow(channelId: bigint) {
    return this.withRetry(() =>
      this.db.channels.findUniqueOrThrow({
        where: { channelid: channelId },
      })
    );
  }

  async createChannel(data: Prisma.channelsCreateInput) {
    return this.withRetry(() =>
      this.db.channels.create({ data })
    );
  }

  async updateChannel(channelId: bigint, data: Prisma.channelsUpdateInput) {
    return this.withRetry(() =>
      this.db.channels.update({
        where: { channelid: channelId },
        data,
      })
    );
  }

  async deleteChannel(channelId: bigint) {
    return this.withRetry(() =>
      this.db.channels.delete({
        where: { channelid: channelId },
      })
    );
  }

  async deleteMany(channelIds: bigint[]) {
    return this.withRetry(() =>
      this.db.channels.deleteMany({
        where: { channelid: { in: channelIds } },
      })
    );
  }

  async addSubchannel(channelId: bigint, subchannelId: bigint) {
    return this.withRetry(() =>
      this.db.channels.update({
        where: { channelid: channelId },
        data: {
          subchannels: { push: subchannelId },
        },
      })
    );
  }

  async removeSubchannel(channelId: bigint, subchannels: bigint[]) {
    return this.withRetry(() =>
      this.db.channels.update({
        where: { channelid: channelId },
        data: {
          subchannels: subchannels,
        },
      })
    );
  }

  async addKeyword(channelId: bigint, keyword: string) {
    return this.withRetry(() =>
      this.db.channels.update({
        where: { channelid: channelId },
        data: {
          keyword: { push: keyword },
        },
      })
    );
  }

  async updateKeywords(channelId: bigint, keywords: string[]) {
    return this.withRetry(() =>
      this.db.channels.update({
        where: { channelid: channelId },
        data: { keyword: keywords },
      })
    );
  }

  async updateTrules(channelId: bigint, trules: string[]) {
    return this.withRetry(() =>
      this.db.channels.update({
        where: { channelid: channelId },
        data: { trules },
      })
    );
  }

  async addTrule(channelId: bigint, rule: string) {
    return this.withRetry(() =>
      this.db.channels.update({
        where: { channelid: channelId },
        data: {
          trules: { push: rule },
        },
      })
    );
  }

  async countByChannelId(channelId: bigint): Promise<number> {
    return this.withRetry(() =>
      this.db.channels.count({
        where: { channelid: channelId },
      })
    );
  }

  async findManyWithSubchannel(subchannelId: bigint) {
    return this.withRetry(() =>
      this.db.channels.findMany({
        where: {
          subchannels: { has: subchannelId },
        },
      })
    );
  }
}
