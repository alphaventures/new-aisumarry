import { PrismaClient } from '@prisma/client';
import { getPrismaClient } from '../core/database/client';
import { logger } from '../core/logger';

export abstract class BaseRepository {
  protected db: PrismaClient;

  constructor() {
    this.db = getPrismaClient();
  }

  protected async withRetry<T>(
    operation: () => Promise<T>,
    maxRetries: number = 3,
    delay: number = 1000
  ): Promise<T> {
    let lastError: Error;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;
        
        if (this.isRetryableError(error) && attempt < maxRetries) {
          logger.warn(
            { error, attempt, maxRetries },
            'Retryable error occurred, retrying...'
          );
          await this.sleep(delay * attempt);
          continue;
        }
        
        throw error;
      }
    }

    throw lastError!;
  }

  private isRetryableError(error: unknown): boolean {
    if (error instanceof Error) {
      const message = error.message.toLowerCase();
      return (
        message.includes('connection') ||
        message.includes('timeout') ||
        message.includes('econnrefused') ||
        message.includes('enotfound') ||
        message.includes('too many connections')
      );
    }
    return false;
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
