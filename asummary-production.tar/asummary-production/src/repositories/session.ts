import { BaseRepository } from './base';

export class SessionRepository extends BaseRepository {
  async findByKey(key: string) {
    return this.withRetry(() =>
      this.db.session.findUnique({
        where: { key },
      })
    );
  }

  async upsert(key: string, value: string) {
    return this.withRetry(() =>
      this.db.session.upsert({
        where: { key },
        create: { key, value },
        update: { value },
      })
    );
  }

  async delete(key: string) {
    return this.withRetry(() =>
      this.db.session.delete({
        where: { key },
      })
    );
  }

  async deleteExpired(expiryDate: Date) {
    return this.withRetry(() =>
      this.db.session.deleteMany({
        where: {
          updatedAt: {
            lt: expiryDate,
          },
        },
      })
    );
  }
}
