import { Context } from 'grammy';
import { ConversationFlavor } from '@grammyjs/conversations';
import { ParseModeFlavor } from '@grammyjs/parse-mode';

export type MyContext = Context & ConversationFlavor & ParseModeFlavor<Context>;
