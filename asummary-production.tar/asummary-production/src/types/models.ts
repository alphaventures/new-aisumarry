export interface PendingOperation {
  userId: bigint;
  operationType: 'channel_add' | 'subchannel_add';
  parentChannel?: bigint;
  channelId?: bigint;
  channelName?: string;
}

export interface TranslationRules {
  photos: boolean;
  videos: boolean;
  audio: boolean;
  voicenotes: boolean;
  documents: boolean;
  buttons: boolean;
  gifs: boolean;
  videonotes: boolean;
  location: boolean;
  surveys: boolean;
  links: boolean;
  albums: boolean;
  stickers: boolean;
  forwards: boolean;
  gameemojis: boolean;
  customemojis: boolean;
  imagenotext: boolean;
  videonotext: boolean;
}

export interface AIResponse {
  candidates?: Array<{
    content: {
      parts: Array<{
        text?: string;
      }>;
    };
  }>;
  choices?: Array<{
    message: {
      content?: string;
    };
  }>;
}

export interface AzureTranslationResponse {
  translations: Array<{
    text: string;
    to: string;
  }>;
}

export interface CountryInfo {
  code: string;
  name: string;
}
