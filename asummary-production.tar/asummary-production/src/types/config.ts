export type { EnvConfig } from '../config/env';

export interface AIProviderConfig {
  model: 'GEMINI' | 'OPENAI' | 'LLAMA';
  token?: string;
  maxTokens: number;
  temperature: number;
  timeout: number;
  maxRetries: number;
}

export interface TranslationConfig {
  key: string;
  location: string;
  endpoint: string;
}

export interface DatabaseConfig {
  url: string;
  poolMin: number;
  poolMax: number;
  connectionTimeout: number;
  idleTimeout: number;
}
