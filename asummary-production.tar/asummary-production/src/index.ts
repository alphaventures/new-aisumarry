import { validateEnv } from './config';
import { setupProcessErrorHandlers } from './core/errors/handlers';
import { logger } from './core/logger';
import { connectDatabase, runMigrations } from './core/database';
import { createBot, startBot } from './bot/bot';
import { startHealthCheckServer } from './health';
import { getConfig } from './config';

async function main() {
  try {
    logger.info('🚀 Starting ASummary Bot (Production Grade)');

    // Validate environment
    logger.info('Validating configuration...');
    validateEnv();
    const config = getConfig();

    logger.info({
      env: config.NODE_ENV,
      version: config.APP_VERSION,
      aiModel: config.AI_MODEL,
    }, 'Configuration validated');

    // Setup error handlers
    setupProcessErrorHandlers();

    // Connect to database
    logger.info('Connecting to database...');
    await connectDatabase();

    // Run migrations in production
    if (config.NODE_ENV === 'production') {
      logger.info('Running database migrations...');
      await runMigrations();
    }

    // Create and start bot
    logger.info('Initializing bot...');
    createBot();
    
    logger.info('Starting bot...');
    await startBot();

    // Start health check server
    logger.info('Starting health check server...');
    startHealthCheckServer();

    logger.info('✅ ASummary Bot is running successfully!');
    logger.info({
      healthCheck: `http://localhost:${config.HEALTH_CHECK_PORT}${config.HEALTH_CHECK_PATH}`,
      mode: config.BOT_WEBHOOK_URL ? 'webhook' : 'polling',
    }, 'Service endpoints');

  } catch (error) {
    logger.fatal({ error }, 'Failed to start application');
    process.exit(1);
  }
}

// Start the application
main();
