import { getPrismaClient } from './client';
import { logger } from '../logger';

export async function checkDatabaseHealth(): Promise<boolean> {
  try {
    const db = getPrismaClient();
    await db.$queryRaw`SELECT 1`;
    return true;
  } catch (error) {
    logger.error({ error }, 'Database health check failed');
    return false;
  }
}

export async function getDatabaseStatus(): Promise<{
  connected: boolean;
  latency?: number;
}> {
  const start = Date.now();
  
  try {
    const db = getPrismaClient();
    await db.$queryRaw`SELECT 1`;
    const latency = Date.now() - start;
    
    return {
      connected: true,
      latency,
    };
  } catch (error) {
    return {
      connected: false,
    };
  }
}
