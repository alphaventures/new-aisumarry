import { PrismaClient } from '@prisma/client';
import { getConfig } from '../../config';
import { logger } from '../logger';

let prisma: PrismaClient | null = null;
let isShuttingDown = false;

export function getPrismaClient(): PrismaClient {
  if (isShuttingDown) {
    throw new Error('Database is shutting down');
  }

  if (!prisma) {
    const config = getConfig();
    
    prisma = new PrismaClient({
      datasources: {
        db: {
          url: config.DATABASE_URL,
        },
      },
      log: config.LOG_LEVEL === 'debug' 
        ? ['query', 'info', 'warn', 'error']
        : ['warn', 'error'],
    });

    prisma.$on('beforeExit' as never, async () => {
      logger.warn('Prisma client is shutting down unexpectedly');
    });

    logger.info('Prisma client initialized');
  }

  return prisma;
}

export async function connectDatabase(): Promise<void> {
  const db = getPrismaClient();
  
  try {
    await db.$connect();
    logger.info('Database connected successfully');
  } catch (error) {
    logger.error({ error }, 'Failed to connect to database');
    throw new Error('Database connection failed');
  }
}

export async function disconnectDatabase(): Promise<void> {
  if (!prisma) return;

  isShuttingDown = true;

  try {
    await prisma.$disconnect();
    logger.info('Database disconnected successfully');
  } catch (error) {
    logger.error({ error }, 'Error disconnecting from database');
  } finally {
    prisma = null;
    isShuttingDown = false;
  }
}

export async function checkDatabaseHealth(): Promise<boolean> {
  if (!prisma) return false;

  try {
    await prisma.$queryRaw`SELECT 1`;
    return true;
  } catch (error) {
    logger.error({ error }, 'Database health check failed');
    return false;
  }
}
