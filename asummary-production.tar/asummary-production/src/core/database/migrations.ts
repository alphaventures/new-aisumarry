import { exec } from 'child_process';
import { promisify } from 'util';
import { logger } from '../logger';
import { getConfig } from '../../config';

const execAsync = promisify(exec);

export async function runMigrations(): Promise<void> {
  const config = getConfig();
  
  try {
    logger.info('Starting database migrations');
    
    const command = config.NODE_ENV === 'production'
      ? 'npx prisma migrate deploy'
      : 'npx prisma migrate dev';

    const { stdout, stderr } = await execAsync(command);
    
    if (stdout) logger.info({ stdout }, 'Migration output');
    if (stderr) logger.warn({ stderr }, 'Migration warnings');
    
    logger.info('Database migrations completed successfully');
  } catch (error) {
    logger.error({ error }, 'Database migration failed');
    throw new Error('Failed to run database migrations');
  }
}

export async function checkMigrationStatus(): Promise<boolean> {
  try {
    const { stdout } = await execAsync('npx prisma migrate status');
    return !stdout.includes('not yet been applied');
  } catch (error) {
    logger.error({ error }, 'Failed to check migration status');
    return false;
  }
}
