export class BotError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    public readonly isOperational: boolean = true
  ) {
    super(message);
    this.name = this.constructor.name;
    Error.captureStackTrace(this, this.constructor);
  }
}

export class DatabaseError extends BotError {
  constructor(message: string) {
    super(message, 'DATABASE_ERROR');
  }
}

export class AIProviderError extends BotError {
  constructor(message: string, public readonly provider: string) {
    super(message, 'AI_PROVIDER_ERROR');
  }
}

export class TranslationError extends BotError {
  constructor(message: string) {
    super(message, 'TRANSLATION_ERROR');
  }
}

export class ConfigurationError extends BotError {
  constructor(message: string) {
    super(message, 'CONFIGURATION_ERROR', false);
  }
}

export class ValidationError extends BotError {
  constructor(message: string) {
    super(message, 'VALIDATION_ERROR');
  }
}

export class RateLimitError extends BotError {
  constructor(message: string) {
    super(message, 'RATE_LIMIT_ERROR');
  }
}

export class ChannelError extends BotError {
  constructor(message: string) {
    super(message, 'CHANNEL_ERROR');
  }
}
