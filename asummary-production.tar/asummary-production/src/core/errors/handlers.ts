import { logger } from '../logger';
import { BotError } from './base';

export function handleError(error: Error): void {
  if (error instanceof BotError && !error.isOperational) {
    logger.fatal({ error }, 'Non-operational error occurred');
    process.exit(1);
  }

  logger.error({ error }, 'Error handled');
}

let isShuttingDown = false;

export function setupProcessErrorHandlers(): void {
  process.on('uncaughtException', (error: Error) => {
    logger.fatal({ error }, 'Uncaught exception');
    process.exit(1);
  });

  process.on('unhandledRejection', (reason: unknown) => {
    logger.fatal({ reason }, 'Unhandled promise rejection');
    process.exit(1);
  });

  process.on('SIGTERM', async () => {
    if (isShuttingDown) return;
    logger.info('SIGTERM received, starting graceful shutdown');
    await gracefulShutdown();
  });

  process.on('SIGINT', async () => {
    if (isShuttingDown) return;
    logger.info('SIGINT received, starting graceful shutdown');
    await gracefulShutdown();
  });
}

async function gracefulShutdown(): Promise<void> {
  if (isShuttingDown) return;
  isShuttingDown = true;

  const { getConfig } = await import('../../config');
  const { stopBot } = await import('../../bot/bot');
  const { disconnectDatabase } = await import('../database/client');
  const { stopHealthCheckServer } = await import('../../health');

  const config = getConfig();
  const timeout = setTimeout(() => {
    logger.error('Graceful shutdown timeout, forcing exit');
    process.exit(1);
  }, config.SHUTDOWN_TIMEOUT);

  try {
    await stopHealthCheckServer();
    await stopBot();
    await disconnectDatabase();
    
    clearTimeout(timeout);
    logger.info('Graceful shutdown completed');
    process.exit(0);
  } catch (error) {
    logger.error({ error }, 'Error during graceful shutdown');
    clearTimeout(timeout);
    process.exit(1);
  }
}
