import { z } from 'zod';
import dotenv from 'dotenv';

dotenv.config();

const envSchema = z.object({
  // Application
  NODE_ENV: z.enum(['development', 'production', 'test']).default('production'),
  LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
  APP_NAME: z.string().default('asummary-bot'),
  APP_VERSION: z.string().default('2.0.0'),

  // Telegram
  BOT_TOKEN: z.string().min(1, 'BOT_TOKEN is required'),
  BOT_WEBHOOK_URL: z.string().url().optional().or(z.literal('')),
  BOT_WEBHOOK_SECRET: z.string().optional(),
  BOT_POLLING_TIMEOUT: z.coerce.number().int().positive().default(30),

  // Database
  DATABASE_URL: z.string().url('DATABASE_URL must be a valid PostgreSQL URL'),
  DB_POOL_MIN: z.coerce.number().int().nonnegative().default(2),
  DB_POOL_MAX: z.coerce.number().int().positive().default(10),
  DB_CONNECTION_TIMEOUT: z.coerce.number().int().positive().default(30000),
  DB_IDLE_TIMEOUT: z.coerce.number().int().positive().default(60000),

  // AI
  AI_MODEL: z.enum(['GEMINI', 'OPENAI', 'LLAMA']),
  AI_TOKEN: z.string().optional(),
  AWS_ACCESS_KEY_ID: z.string().optional(),
  AWS_SECRET_ACCESS_KEY: z.string().optional(),
  AWS_REGION: z.string().default('us-east-1'),
  AWS_BEDROCK_MODEL_ID: z.string().default('meta.llama3-8b-instruct-v1:0'),
  AI_MAX_TOKENS: z.coerce.number().int().positive().default(2048),
  AI_TEMPERATURE: z.coerce.number().min(0).max(2).default(0.4),
  AI_REQUEST_TIMEOUT: z.coerce.number().int().positive().default(30000),
  AI_MAX_RETRIES: z.coerce.number().int().nonnegative().default(3),

  // Azure Translator
  AZURE_TRANSLATOR_KEY: z.string().min(1, 'AZURE_TRANSLATOR_KEY is required'),
  AZURE_TRANSLATOR_LOCATION: z.string().min(1, 'AZURE_TRANSLATOR_LOCATION is required'),
  AZURE_TRANSLATOR_ENDPOINT: z.string().url().default('https://api.cognitive.microsofttranslator.com'),

  // Rate Limiting
  RATE_LIMIT_WINDOW: z.coerce.number().int().positive().default(60000),
  RATE_LIMIT_MAX_REQUESTS: z.coerce.number().int().positive().default(30),

  // Health Check
  HEALTH_CHECK_PORT: z.coerce.number().int().positive().default(3000),
  HEALTH_CHECK_PATH: z.string().default('/health'),

  // Monitoring
  SENTRY_DSN: z.string().optional(),
  ENABLE_METRICS: z.coerce.boolean().default(false),

  // Shutdown
  SHUTDOWN_TIMEOUT: z.coerce.number().int().positive().default(30000),
});

/**
 * Validate environment variables and return typed config
 */
export function validateEnv() {
  try {
    const parsed = envSchema.parse(process.env);

    // Additional validation based on AI_MODEL
    if (parsed.AI_MODEL === 'GEMINI' || parsed.AI_MODEL === 'OPENAI') {
      if (!parsed.AI_TOKEN) {
        throw new Error(`AI_TOKEN is required when AI_MODEL is ${parsed.AI_MODEL}`);
      }
    }

    if (parsed.AI_MODEL === 'LLAMA') {
      if (!parsed.AWS_ACCESS_KEY_ID || !parsed.AWS_SECRET_ACCESS_KEY) {
        throw new Error('AWS credentials are required when AI_MODEL is LLAMA');
      }
    }

    return parsed;
  } catch (error) {
    if (error instanceof z.ZodError) {
      const errors = error.errors.map(err => `${err.path.join('.')}: ${err.message}`).join('\n');
      throw new Error(`Environment validation failed:\n${errors}`);
    }
    throw error;
  }
}

export type EnvConfig = z.infer<typeof envSchema>;
