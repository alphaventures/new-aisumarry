import { getAIProvider } from './factory';
import { CircuitBreaker } from './circuit-breaker';
import { getConfig } from '../../config';
import { logger } from '../../core/logger';

const circuitBreaker = new CircuitBreaker(5, 60000);

export async function summarizeContent(
  prompt: string,
  content: string,
  maxTokens?: number
): Promise<string> {
  const config = getConfig();
  const tokens = maxTokens || config.AI_MAX_TOKENS;

  logger.info('Initiating AI summary request');

  try {
    return await circuitBreaker.execute(async () => {
      const provider = getAIProvider();
      return await provider.query(prompt, content, tokens);
    });
  } catch (error) {
    logger.error({ error }, 'AI summary request failed');
    throw error;
  }
}

export { getAIProvider, resetAIProvider } from './factory';
