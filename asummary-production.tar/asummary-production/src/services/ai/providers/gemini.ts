import axios from 'axios';
import { BaseAIProvider } from './base';
import { AIProviderError } from '../../../core/errors/base';
import { logger } from '../../../core/logger';
import { AIResponse } from '../../../types/models';

export class GeminiProvider extends BaseAIProvider {
  constructor(private apiKey: string, private temperature: number) {
    super();
  }

  getName(): string {
    return 'Gemini';
  }

  async query(prompt: string, content: string, maxTokens: number): Promise<string> {
    logger.debug('Making Gemini AI request');
    
    const queryUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${this.apiKey}`;
    
    try {
      const response = await axios.post<AIResponse>(
        queryUrl,
        {
          contents: [
            {
              parts: [
                {
                  text: this.combinePrompt(prompt, content),
                },
              ],
            },
          ],
          generationConfig: {
            temperature: this.temperature,
            maxOutputTokens: maxTokens,
          },
        },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      const text = response.data.candidates?.[0]?.content?.parts?.[0]?.text;
      
      if (!text) {
        logger.error({ response: response.data }, 'Invalid Gemini response');
        throw new AIProviderError('Invalid response from Gemini', 'GEMINI');
      }

      return text;
    } catch (error) {
      if (axios.isAxiosError(error)) {
        logger.error(
          { error: error.response?.data || error.message },
          'Gemini API request failed'
        );
        throw new AIProviderError(
          `Gemini API error: ${error.message}`,
          'GEMINI'
        );
      }
      throw error;
    }
  }
}
