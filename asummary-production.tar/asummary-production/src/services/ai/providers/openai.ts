import axios from 'axios';
import { BaseAIProvider } from './base';
import { AIProviderError } from '../../../core/errors/base';
import { logger } from '../../../core/logger';
import { AIResponse } from '../../../types/models';

export class OpenAIProvider extends BaseAIProvider {
  constructor(private apiKey: string, private temperature: number) {
    super();
  }

  getName(): string {
    return 'OpenAI';
  }

  async query(prompt: string, content: string, maxTokens: number): Promise<string> {
    logger.debug('Making OpenAI request');
    
    try {
      const response = await axios.post<AIResponse>(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-4o-mini',
          messages: [
            {
              role: 'user',
              content: this.combinePrompt(prompt, content),
            },
          ],
          max_tokens: maxTokens,
          temperature: this.temperature,
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.apiKey}`,
          },
        }
      );

      const text = response.data.choices?.[0]?.message?.content;
      
      if (!text) {
        logger.error({ response: response.data }, 'Invalid OpenAI response');
        throw new AIProviderError('Invalid response from OpenAI', 'OPENAI');
      }

      return text;
    } catch (error) {
      if (axios.isAxiosError(error)) {
        logger.error(
          { error: error.response?.data || error.message },
          'OpenAI API request failed'
        );
        throw new AIProviderError(
          `OpenAI API error: ${error.message}`,
          'OPENAI'
        );
      }
      throw error;
    }
  }
}
