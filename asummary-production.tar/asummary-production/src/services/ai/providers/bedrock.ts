import { 
  BedrockRuntimeClient, 
  ConverseCommand, 
  Message,
  BedrockRuntimeServiceException 
} from '@aws-sdk/client-bedrock-runtime';
import { BaseAIProvider } from './base';
import { AIProviderError } from '../../../core/errors/base';
import { logger } from '../../../core/logger';

export class BedrockProvider extends BaseAIProvider {
  private client: BedrockRuntimeClient;

  constructor(
    accessKeyId: string,
    secretAccessKey: string,
    region: string,
    private modelId: string,
    private temperature: number
  ) {
    super();
    this.client = new BedrockRuntimeClient({
      region,
      credentials: {
        accessKeyId,
        secretAccessKey,
      },
    });
  }

  getName(): string {
    return 'AWS Bedrock';
  }

  async query(prompt: string, content: string, maxTokens: number): Promise<string> {
    logger.debug('Making AWS Bedrock request');
    
    try {
      const conversation: Message[] = [
        {
          role: 'user',
          content: [{ text: this.combinePrompt(prompt, content) }],
        },
      ];

      const command = new ConverseCommand({
        modelId: this.modelId,
        messages: conversation,
        inferenceConfig: { 
          maxTokens, 
          temperature: this.temperature 
        },
      });

      const response = await this.client.send(command);
      const responseText = response.output?.message?.content?.[0]?.text;

      if (!responseText) {
        logger.error({ response }, 'Invalid Bedrock response');
        throw new AIProviderError('Invalid response from AWS Bedrock', 'BEDROCK');
      }

      return responseText;
    } catch (error) {
      if (error instanceof BedrockRuntimeServiceException) {
        logger.error(
          { error: error.message },
          'AWS Bedrock request failed'
        );
        throw new AIProviderError(
          `AWS Bedrock error: ${error.message}`,
          'BEDROCK'
        );
      }
      throw error;
    }
  }
}
