export interface AIProvider {
  query(prompt: string, content: string, maxTokens: number): Promise<string>;
  getName(): string;
}

export abstract class BaseAIProvider implements AIProvider {
  abstract query(prompt: string, content: string, maxTokens: number): Promise<string>;
  abstract getName(): string;

  protected combinePrompt(prompt: string, content: string): string {
    return `${prompt}\n\nContent: ${content}`;
  }
}
