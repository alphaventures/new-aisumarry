import { AIProvider } from './providers/base';
import { GeminiProvider } from './providers/gemini';
import { OpenAIProvider } from './providers/openai';
import { BedrockProvider } from './providers/bedrock';
import { getConfig } from '../../config';
import { ConfigurationError } from '../../core/errors/base';

let providerInstance: AIProvider | null = null;

export function getAIProvider(): AIProvider {
  if (providerInstance) {
    return providerInstance;
  }

  const config = getConfig();

  switch (config.AI_MODEL) {
    case 'GEMINI':
      if (!config.AI_TOKEN) {
        throw new ConfigurationError('AI_TOKEN is required for Gemini');
      }
      providerInstance = new GeminiProvider(
        config.AI_TOKEN,
        config.AI_TEMPERATURE
      );
      break;

    case 'OPENAI':
      if (!config.AI_TOKEN) {
        throw new ConfigurationError('AI_TOKEN is required for OpenAI');
      }
      providerInstance = new OpenAIProvider(
        config.AI_TOKEN,
        config.AI_TEMPERATURE
      );
      break;

    case 'LLAMA':
      if (!config.AWS_ACCESS_KEY_ID || !config.AWS_SECRET_ACCESS_KEY) {
        throw new ConfigurationError('AWS credentials are required for Bedrock');
      }
      providerInstance = new BedrockProvider(
        config.AWS_ACCESS_KEY_ID,
        config.AWS_SECRET_ACCESS_KEY,
        config.AWS_REGION,
        config.AWS_BEDROCK_MODEL_ID,
        config.AI_TEMPERATURE
      );
      break;

    default:
      throw new ConfigurationError(`Unsupported AI model: ${config.AI_MODEL}`);
  }

  return providerInstance;
}

export function resetAIProvider(): void {
  providerInstance = null;
}
