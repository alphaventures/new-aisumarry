import { logger } from '../../core/logger';

type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export class CircuitBreaker {
  private failures = 0;
  private lastFailTime = 0;
  private state: CircuitState = 'CLOSED';
  private successCount = 0;

  constructor(
    private maxFailures: number = 5,
    private resetTimeout: number = 60000,
    private halfOpenSuccessThreshold: number = 2
  ) {}

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === 'OPEN') {
      if (Date.now() - this.lastFailTime > this.resetTimeout) {
        logger.info('Circuit breaker transitioning to HALF_OPEN');
        this.state = 'HALF_OPEN';
        this.successCount = 0;
      } else {
        throw new Error('Circuit breaker is OPEN - too many failures');
      }
    }

    try {
      const result = await operation();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  private onSuccess() {
    if (this.state === 'HALF_OPEN') {
      this.successCount++;
      if (this.successCount >= this.halfOpenSuccessThreshold) {
        logger.info('Circuit breaker transitioning to CLOSED');
        this.state = 'CLOSED';
        this.failures = 0;
      }
    } else {
      this.failures = 0;
      this.state = 'CLOSED';
    }
  }

  private onFailure() {
    this.failures++;
    this.lastFailTime = Date.now();

    if (this.state === 'HALF_OPEN') {
      logger.warn('Circuit breaker transitioning back to OPEN from HALF_OPEN');
      this.state = 'OPEN';
      return;
    }

    if (this.failures >= this.maxFailures) {
      logger.warn(
        { failures: this.failures, maxFailures: this.maxFailures },
        'Circuit breaker transitioning to OPEN'
      );
      this.state = 'OPEN';
    }
  }

  getState(): CircuitState {
    return this.state;
  }

  reset(): void {
    this.failures = 0;
    this.state = 'CLOSED';
    this.successCount = 0;
  }
}
