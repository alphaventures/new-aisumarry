import { TranslationRules } from '../../types/models';

export function parseTrules(trules: string[]): TranslationRules {
  return {
    photos: trules.includes('photos'),
    videos: trules.includes('videos'),
    audio: trules.includes('audio'),
    voicenotes: trules.includes('voicenotes'),
    documents: trules.includes('docs'),
    buttons: trules.includes('buttons'),
    gifs: trules.includes('gifs'),
    videonotes: trules.includes('videonotes'),
    location: trules.includes('location'),
    surveys: trules.includes('surveys'),
    links: trules.includes('links'),
    albums: trules.includes('albums'),
    stickers: trules.includes('stickers'),
    forwards: trules.includes('forwards'),
    gameemojis: trules.includes('gemojis'),
    customemojis: trules.includes('cemojis'),
    imagenotext: trules.includes('imagenotext'),
    videonotext: trules.includes('videonotext'),
  };
}

export function shouldSkipMessage(ctx: any, rules: TranslationRules): boolean {
  const msg = ctx.msg || ctx.channelPost;
  
  if (!msg) return true;

  if (msg.photo && !rules.photos) return true;
  if (msg.video && !rules.videos) return true;
  if (msg.audio && !rules.audio) return true;
  if (msg.voice && !rules.voicenotes) return true;
  if (msg.document && !rules.documents) return true;
  if (msg.reply_markup?.inline_keyboard && !rules.buttons) return true;
  if (msg.animation && !rules.gifs) return true;
  if (msg.video_note && !rules.videonotes) return true;
  if (msg.location && !rules.location) return true;
  if (msg.poll && !rules.surveys) return true;
  if (msg.media_group_id && !rules.albums) return true;
  if (msg.sticker && !rules.stickers) return true;
  if (msg.forward_origin && !rules.forwards) return true;
  if (msg.dice && !rules.gameemojis) return true;
  
  // Check for links
  const hasLinks = (msg.entities || msg.caption_entities || []).some(
    (e: any) => e.type === 'text_link' || e.type === 'url'
  );
  if (hasLinks && !rules.links) return true;

  // Check for custom emojis
  const hasCustomEmojis = (msg.entities || msg.caption_entities || []).some(
    (e: any) => e.type === 'custom_emoji'
  );
  if (hasCustomEmojis && !rules.customemojis) return true;

  // Image/video without text
  if (msg.photo && !msg.caption && !rules.imagenotext) return true;
  if (msg.video && !msg.caption && !rules.videonotext) return true;

  return false;
}
