import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
import { getConfig } from '../../config';
import { TranslationError } from '../../core/errors/base';
import { logger } from '../../core/logger';
import { AzureTranslationResponse } from '../../types/models';

export async function translateText(
  text: string,
  targetLanguage: string,
  sourceLanguage?: string
): Promise<string> {
  const config = getConfig();

  logger.debug({ targetLanguage, sourceLanguage }, 'Translating text');

  try {
    const response = await axios.post<AzureTranslationResponse[]>(
      `${config.AZURE_TRANSLATOR_ENDPOINT}/translate`,
      [{ text }],
      {
        params: {
          'api-version': '3.0',
          from: sourceLanguage,
          to: targetLanguage,
        },
        headers: {
          'Ocp-Apim-Subscription-Key': config.AZURE_TRANSLATOR_KEY,
          'Ocp-Apim-Subscription-Region': config.AZURE_TRANSLATOR_LOCATION,
          'Content-Type': 'application/json',
          'X-ClientTraceId': uuidv4(),
        },
      }
    );

    const translatedText = response.data[0]?.translations?.[0]?.text;

    if (!translatedText) {
      logger.error({ response: response.data }, 'Invalid translation response');
      throw new TranslationError('Invalid response from Azure Translator');
    }

    return translatedText;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      logger.error(
        { error: error.response?.data || error.message },
        'Translation request failed'
      );
      throw new TranslationError(
        `Translation error: ${error.message}`
      );
    }
    throw error;
  }
}

export async function detectLanguage(text: string): Promise<string> {
  const config = getConfig();

  try {
    const response = await axios.post(
      `${config.AZURE_TRANSLATOR_ENDPOINT}/detect`,
      [{ text }],
      {
        params: {
          'api-version': '3.0',
        },
        headers: {
          'Ocp-Apim-Subscription-Key': config.AZURE_TRANSLATOR_KEY,
          'Ocp-Apim-Subscription-Region': config.AZURE_TRANSLATOR_LOCATION,
          'Content-Type': 'application/json',
        },
      }
    );

    return response.data[0]?.language || 'en';
  } catch (error) {
    logger.error({ error }, 'Language detection failed');
    return 'en'; // Default to English
  }
}
