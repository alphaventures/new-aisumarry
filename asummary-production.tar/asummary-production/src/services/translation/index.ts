export { translateText, detectLanguage } from './azure';
