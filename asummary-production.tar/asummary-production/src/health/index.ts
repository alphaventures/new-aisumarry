import http from 'http';
import { logger } from '../core/logger';
import { getConfig } from '../config';
import { checkDatabaseHealth } from '../core/database/health';

let server: http.Server | null = null;

interface HealthStatus {
  status: 'healthy' | 'unhealthy';
  timestamp: string;
  checks: {
    database: boolean;
    bot: boolean;
  };
}

async function checkHealth(): Promise<HealthStatus> {
  const checks = {
    database: await checkDatabaseHealth(),
    bot: false,
  };

  try {
    const { getBot } = await import('../bot/bot');
    const bot = getBot();
    const me = await bot.api.getMe();
    checks.bot = !!me.id;
  } catch (error) {
    logger.warn({ error }, 'Bot health check failed');
  }

  const isHealthy = checks.database && checks.bot;

  return {
    status: isHealthy ? 'healthy' : 'unhealthy',
    timestamp: new Date().toISOString(),
    checks,
  };
}

export function startHealthCheckServer(): void {
  const config = getConfig();

  server = http.createServer(async (req, res) => {
    if (req.url === config.HEALTH_CHECK_PATH && req.method === 'GET') {
      const health = await checkHealth();
      const statusCode = health.status === 'healthy' ? 200 : 503;

      res.writeHead(statusCode, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(health, null, 2));
    } else if (req.url === '/ready' && req.method === 'GET') {
      // Readiness probe
      res.writeHead(200);
      res.end('OK');
    } else {
      res.writeHead(404);
      res.end('Not Found');
    }
  });

  server.listen(config.HEALTH_CHECK_PORT, () => {
    logger.info(
      { port: config.HEALTH_CHECK_PORT, path: config.HEALTH_CHECK_PATH },
      'Health check server started'
    );
  });
}

export async function stopHealthCheckServer(): Promise<void> {
  if (!server) return;

  return new Promise((resolve) => {
    server!.close(() => {
      logger.info('Health check server stopped');
      server = null;
      resolve();
    });
  });
}
