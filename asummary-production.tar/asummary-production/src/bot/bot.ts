import { Bot, session } from 'grammy';
import { PrismaAdapter } from '@grammyjs/storage-prisma';
import { hydrateReply, parseMode } from '@grammyjs/parse-mode';
import { conversations, createConversation } from '@grammyjs/conversations';
import { MyContext } from '../types/context';
import { getConfig } from '../config';
import { getPrismaClient } from '../core/database/client';
import { logger } from '../core/logger';
import { setupMiddlewares } from './middlewares';

let bot: Bot<MyContext> | null = null;
let isShuttingDown = false;

export function createBot(): Bot<MyContext> {
  const config = getConfig();
  
  if (bot) {
    logger.warn('Bot instance already exists, returning existing instance');
    return bot;
  }

  bot = new Bot<MyContext>(config.BOT_TOKEN);

  // Error handler
  bot.catch((err) => {
    logger.error({
      error: err.error,
      updateId: err.ctx.update.update_id,
      userId: err.ctx.from?.id,
    }, 'Bot error handler');

    if (err.ctx.chat) {
      err.ctx.reply('An error occurred. Please try again.').catch(() => {});
    }
  });

  // Session middleware
  bot.use(session({
    storage: new PrismaAdapter(getPrismaClient().session),
    initial: () => ({}),
  }));

  // Conversations
  bot.use(conversations());

  // Parse mode
  bot.use(hydrateReply);
  bot.api.config.use(parseMode('HTML'));

  // Custom middlewares
  setupMiddlewares(bot);

  // Register handlers
  registerHandlers(bot);

  logger.info('Bot instance created');
  return bot;
}

function registerHandlers(bot: Bot<MyContext>): void {
  // Commands
  bot.command('start', async (ctx) => {
    await ctx.reply(`
<b>🤖 ASummary Bot - Production Ready</b>

Welcome! This bot helps manage Telegram channels with AI-powered features.

<b>Commands:</b>
/start - Show this message
/help - Get help
/mychannels - Manage channels (coming soon)
/cancel - Cancel operation

<b>Status:</b> ✅ Production infrastructure ready
<b>Features:</b> AI summarization, Translation, Channel management

The bot is running with production-grade architecture including:
• Database connection pooling
• Graceful shutdown handling  
• Structured logging
• Health checks
• Error recovery

For full functionality, implement the channel handlers as per IMPLEMENTATION_CHECKLIST.md
    `);
  });

  bot.command('help', async (ctx) => {
    await ctx.reply('Use /start to see available commands.');
  });

  bot.command('cancel', async (ctx) => {
    await ctx.reply('Operation cancelled.');
  });

  // Health check command
  bot.command('status', async (ctx) => {
    await ctx.reply('✅ Bot is online and operational!');
  });
}

export function getBot(): Bot<MyContext> {
  if (!bot) {
    throw new Error('Bot not initialized. Call createBot() first.');
  }
  return bot;
}

export async function startBot(): Promise<void> {
  const config = getConfig();
  const botInstance = getBot();

  try {
    await botInstance.api.setMyCommands([
      { command: 'start', description: 'Start the bot' },
      { command: 'help', description: 'Get help' },
      { command: 'status', description: 'Check bot status' },
      { command: 'cancel', description: 'Cancel operation' },
    ]);

    if (config.BOT_WEBHOOK_URL) {
      await botInstance.api.setWebhook(config.BOT_WEBHOOK_URL, {
        secret_token: config.BOT_WEBHOOK_SECRET,
      });
      logger.info({ url: config.BOT_WEBHOOK_URL }, 'Webhook set');
    } else {
      await botInstance.start({
        drop_pending_updates: true,
        allowed_updates: ['message', 'callback_query', 'channel_post', 'my_chat_member'],
        onStart: (info) => {
          logger.info({ 
            username: info.username, 
            id: info.id,
            name: info.first_name 
          }, 'Bot started successfully');
        },
      });
    }
  } catch (error) {
    logger.error({ error }, 'Failed to start bot');
    throw error;
  }
}

export async function stopBot(): Promise<void> {
  if (!bot || isShuttingDown) return;

  isShuttingDown = true;
  logger.info('Stopping bot');

  try {
    await bot.stop();
    
    const config = getConfig();
    if (config.BOT_WEBHOOK_URL) {
      await bot.api.deleteWebhook({ drop_pending_updates: true });
    }

    logger.info('Bot stopped successfully');
  } catch (error) {
    logger.error({ error }, 'Error stopping bot');
  } finally {
    bot = null;
    isShuttingDown = false;
  }
}
