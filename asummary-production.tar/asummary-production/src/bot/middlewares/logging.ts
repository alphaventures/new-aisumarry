import { Middleware } from 'grammy';
import { MyContext } from '../../types/context';
import { logger } from '../../core/logger';

export function loggingMiddleware(): Middleware<MyContext> {
  return async (ctx, next) => {
    const start = Date.now();
    
    logger.debug({
      updateId: ctx.update.update_id,
      userId: ctx.from?.id,
      username: ctx.from?.username,
      chatId: ctx.chat?.id,
      chatType: ctx.chat?.type,
      messageId: ctx.msg?.message_id,
    }, 'Processing update');

    try {
      await next();
    } finally {
      const duration = Date.now() - start;
      logger.debug({ duration, updateId: ctx.update.update_id }, 'Update processed');
    }
  };
}
