import { Middleware } from 'grammy';
import { MyContext } from '../../types/context';
import { logger } from '../../core/logger';
import { BotError } from '../../core/errors/base';

export function errorMiddleware(): Middleware<MyContext> {
  return async (ctx, next) => {
    try {
      await next();
    } catch (error) {
      logger.error({
        error,
        userId: ctx.from?.id,
        chatId: ctx.chat?.id,
        updateId: ctx.update.update_id,
      }, 'Error in middleware chain');

      const userMessage = error instanceof BotError
        ? error.message
        : 'An unexpected error occurred. Please try again later.';

      if (ctx.chat) {
        await ctx.reply(userMessage).catch(
          (e) => logger.error({ error: e }, 'Failed to send error message to user')
        );
      }
    }
  };
}
