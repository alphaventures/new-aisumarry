import { Middleware } from 'grammy';
import { MyContext } from '../../types/context';
import { getConfig } from '../../config';
import { logger } from '../../core/logger';

interface RateLimitEntry {
  count: number;
  resetAt: number;
}

const rateLimitMap = new Map<number, RateLimitEntry>();

// Cleanup old entries every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [userId, entry] of rateLimitMap.entries()) {
    if (now > entry.resetAt) {
      rateLimitMap.delete(userId);
    }
  }
}, 5 * 60 * 1000);

export function rateLimitMiddleware(): Middleware<MyContext> {
  return async (ctx, next) => {
    if (!ctx.from) {
      return next();
    }

    const config = getConfig();
    const userId = ctx.from.id;
    const now = Date.now();

    let entry = rateLimitMap.get(userId);

    if (!entry || now > entry.resetAt) {
      entry = {
        count: 0,
        resetAt: now + config.RATE_LIMIT_WINDOW,
      };
      rateLimitMap.set(userId, entry);
    }

    entry.count++;

    if (entry.count > config.RATE_LIMIT_MAX_REQUESTS) {
      logger.warn({ userId, count: entry.count }, 'Rate limit exceeded');
      await ctx.reply('⚠️ Too many requests. Please slow down and try again in a minute.');
      return;
    }

    return next();
  };
}
