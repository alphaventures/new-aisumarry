import { Bot } from 'grammy';
import { MyContext } from '../../types/context';
import { loggingMiddleware } from './logging';
import { errorMiddleware } from './error';
import { rateLimitMiddleware } from './rate-limit';

export function setupMiddlewares(bot: Bot<MyContext>): void {
  // Order matters: logging -> rate limiting -> error handling
  bot.use(loggingMiddleware());
  bot.use(rateLimitMiddleware());
  bot.use(errorMiddleware());
}
