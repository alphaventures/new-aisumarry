import { MessageEntity } from "@grammyjs/types";
import { InlineKeyboard } from "grammy";

/**
 * Parses messages and entity to give HTML formatted message.
 * @param text
 * @param entities
 */
export const messageToHTMLMessage = (text: string, entities: MessageEntity[]) => {
    if (!entities || !text) {
        return text;
    }
    let tags: { index: number; tag: string | undefined }[] = [];
    entities.forEach((entity) => {
        const startTag = getTag(entity, text);
        if (startTag == undefined) return;
        let searchTag = tags.filter((tag) => tag.index === entity.offset);
        if (searchTag.length > 0 && startTag) searchTag[0].tag += startTag;
        else
            tags.push({
                index: entity.offset,
                tag: startTag
            });
        let closeTag: string;
        if (startTag?.indexOf("<a ") === 0)
            closeTag = "</a>";
        else if (startTag?.indexOf("<tg-emoji ") === 0)
            closeTag = "</tg-emoji>"
        else
            closeTag = "</" + startTag?.slice(1);

        searchTag = tags.filter((tag) => tag.index === entity.offset + entity.length);
        if (searchTag.length > 0) searchTag[0].tag = closeTag + searchTag[0].tag;
        else
            tags.push({
                index: entity.offset + entity.length,
                tag: closeTag
            });
    });
    let html = "";
    for (let i = 0; i < text.length; i++) {
        const tag = tags.filter((tag) => tag.index === i);
        tags = tags.filter((tag) => tag.index !== i);
        if (tag.length > 0) html += tag[0].tag;
        html += text[i];
    }
    if (tags.length > 0) html += tags[0].tag;
    return html;
};
const getTag = (entity: MessageEntity, text: string) => {
    const entityText = text.slice(entity.offset, entity.offset + entity.length);
    switch (entity.type) {
        case "bold":
            return `<strong>`;
        case "text_link":
            return `<a href="${entity.url}" target="_blank">`;
        // case "url":
            // return `<a href="${entityText}" target="_blank">`;
        case "italic":
            return `<em>`;
        case "code":
            return `<code>`;
        case "strikethrough":
            return `<s>`;
        case "underline":
            return `<u>`;
        case "pre":
            return `<pre>`;
        case "mention":
            return `<a href="https://t.me/${entityText.replace("@", "")}" target="_blank">`;
        case "email":
            return `<a href="mailto:${entityText}">`;
        case "phone_number":
            return `<a href="tel:${entityText}">`;
        case "spoiler":
            return `<tg-spoiler>`;
        case "custom_emoji":
            return `<tg-emoji emoji-id="${entity.custom_emoji_id}">`

    }
};


export function markdownToHtml(markdown: string): string {
    // Helper function to escape special HTML characters
    const escapeHtml = (text: string): string => {
        return text
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    };

    // Convert headers to bold
    markdown = markdown.replace(/^(#{1,6})\s(.+)$/gm, (match, hashes, content) => {
        return `<b>${escapeHtml(content.trim())}</b>`;
    });

    // Convert bold
    markdown = markdown.replace(/\*\*(.*?)\*\*/g, "<b>$1</b>");

    // Convert italic
    markdown = markdown.replace(/\*(.*?)\*/g, "<em>$1</em>");

    // Convert inline code
    markdown = markdown.replace(/`([^`]+)`/g, "<code>$1</code>");

    // Convert links
    markdown = markdown.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');

    // Convert line breaks
    // markdown = markdown.replace(/\n\n/g, "<br>");

    return markdown.trim();
}

export function removeMarkdown(markdown: string): string {
    const escapeHtml = (text: string): string => {
        return text
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    };

    // Convert headers to bold
    markdown = markdown.replace(/^(#{1,6})\s(.+)$/gm, (match, hashes, content) => {
        return `${escapeHtml(content.trim())}`;
    });

    // Convert bold
    markdown = markdown.replace(/\*\*(.*?)\*\*/g, "$1");

    // Convert italic
    markdown = markdown.replace(/\*(.*?)\*/g, "$1");

    // Convert inline code
    markdown = markdown.replace(/`([^`]+)`/g, "$1");

    // Convert links
    markdown = markdown.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');

    // Convert line breaks
    // markdown = markdown.replace(/\n\n/g, "<br>");

    return markdown.trim();
}

/**
 * Parses messages and entities to give Markdown formatted message.
 * @param text
 * @param entities
 */
export const messageToMarkdownMessage = (text: string, entities: MessageEntity[]) => {
    if (!entities || !text) {
        return text;
    }
    let tags: { index: number; tag: string | undefined }[] = [];
    entities.forEach((entity) => {
        const startTag = getMarkdownTag(entity, text, true);
        if (startTag == undefined) return;
        let searchTag = tags.filter((tag) => tag.index === entity.offset);
        if (searchTag.length > 0 && startTag) searchTag[0].tag += startTag;
        else
            tags.push({
                index: entity.offset,
                tag: startTag
            });
        const endTag = getMarkdownTag(entity, text, false);
        searchTag = tags.filter((tag) => tag.index === entity.offset + entity.length);
        if (searchTag.length > 0) searchTag[0].tag = endTag + searchTag[0].tag;
        else
            tags.push({
                index: entity.offset + entity.length,
                tag: endTag
            });
    });
    let markdown = "";
    for (let i = 0; i < text.length; i++) {
        const tag = tags.filter((tag) => tag.index === i);
        tags = tags.filter((tag) => tag.index !== i);
        if (tag.length > 0) markdown += tag[0].tag;
        markdown += text[i];
    }
    if (tags.length > 0) markdown += tags[0].tag;
    return markdown;
};

const getMarkdownTag = (entity: MessageEntity, text: string, isStart: boolean) => {
    const entityText = text.slice(entity.offset, entity.offset + entity.length);
    switch (entity.type) {
        case "bold":
            return "**";
        case "text_link":
            return isStart ? "[" : `](${entity.url})`;
        case "url":
            return isStart ? "" : `(${entityText})`;
        case "italic":
            return "_";
        case "code":
            return "`";
        case "strikethrough":
            return "~~";
        case "underline":
            return "__";
        case "pre":
            return "```";
        case "mention":
            return isStart ? "" : `](https://t.me/${entityText.replace("@", "")})`;
        case "email":
            return isStart ? "" : `](mailto:${entityText})`;
        case "phone_number":
            return isStart ? "" : `](tel:${entityText})`;
        case "spoiler":
            return "||";
        case "custom_emoji":
            // Markdown doesn't have a standard way to represent custom emojis
            return "";
    }
};

export function parseInlineKeyboard(input: string): InlineKeyboard {
    const keyboard = new InlineKeyboard();
    const rows = input.split('\n');

    rows.forEach((row) => {
        const buttons = row.split('&&');
        const rowButtons = buttons.map((button) => {
            const [text, url] = button.split('-').map((part) => part.trim());
            return { text, url };
        });

        keyboard.row(...rowButtons.map((button) => ({ text: button.text, url: button.url })));
    });

    return keyboard;
}
